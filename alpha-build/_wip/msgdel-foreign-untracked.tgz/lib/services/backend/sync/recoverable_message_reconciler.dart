import 'package:bluebubbles/database/database.dart';
import 'package:bluebubbles/database/models.dart';
import 'package:bluebubbles/services/services.dart';
import 'package:bluebubbles/utils/logger/logger.dart';

/// A parsed `/server/recoverable-messages/snapshot` response.
class RecoverableMessageSnapshot {
  const RecoverableMessageSnapshot({
    this.deletedByChat = const {},
    this.generatedAt = 0,
    this.skipped = false,
    this.reason,
  });

  final Map<String, Set<String>> deletedByChat;
  final int generatedAt;
  final bool skipped;
  final String? reason;

  Set<String> get allDeletedGuids => deletedByChat.values.expand((guids) => guids).toSet();
}

/// What the catch-up pass should change locally.
class RecoverableMessageActions {
  const RecoverableMessageActions({this.toHide = const {}, this.toRestore = const {}});

  final Set<String> toHide;
  final Set<String> toRestore;

  bool get isEmpty => toHide.isEmpty && toRestore.isEmpty;
}

/// Parses an Apple-authoritative Recently Deleted snapshot.
///
/// Anything unexpected refuses the ENTIRE snapshot rather than applying part of
/// it. The snapshot is what licenses the client to un-hide messages, so a
/// truncated or malformed response must never be read as "Apple deleted
/// nothing" and undo deletions the user actually made.
///
/// Kept free of Logger (which resolves a GetIt singleton) so it stays unit
/// testable; the caller logs the refusal reason.
RecoverableMessageSnapshot parseRecoverableMessageSnapshot(Map<String, dynamic> payload) {
  if (payload['schemaVersion'] != 1) {
    return const RecoverableMessageSnapshot(skipped: true, reason: 'schema');
  }
  if (payload['complete'] != true) {
    return const RecoverableMessageSnapshot(skipped: true, reason: 'incomplete');
  }

  final generatedAt = payload['generatedAt'];
  if (generatedAt is! int || generatedAt < 0) {
    return const RecoverableMessageSnapshot(skipped: true, reason: 'malformed');
  }

  final rawChats = payload['chats'];
  if (rawChats is! List) {
    return const RecoverableMessageSnapshot(skipped: true, reason: 'malformed');
  }

  final deletedByChat = <String, Set<String>>{};
  for (final raw in rawChats) {
    if (raw is! Map) {
      return const RecoverableMessageSnapshot(skipped: true, reason: 'malformed');
    }
    final guid = raw['guid'];
    final rawGuids = raw['deletedMessageGuids'];
    if (guid is! String || guid.isEmpty || rawGuids is! List) {
      return const RecoverableMessageSnapshot(skipped: true, reason: 'malformed');
    }
    if (rawGuids.any((messageGuid) => messageGuid is! String || messageGuid.isEmpty)) {
      return const RecoverableMessageSnapshot(skipped: true, reason: 'malformed');
    }
    deletedByChat.putIfAbsent(guid, () => <String>{}).addAll(rawGuids.cast<String>());
  }

  return RecoverableMessageSnapshot(deletedByChat: deletedByChat, generatedAt: generatedAt);
}

/// Works out the minimum set of local changes that makes the device agree with
/// Apple's Recently Deleted folder.
///
/// Both directions are restricted to messages the device actually holds: a
/// deleted message that was never downloaded is nothing to hide, and a hidden
/// row the device no longer has is nothing to restore.
RecoverableMessageActions resolveRecoverableMessageActions({
  required Set<String> serverDeletedGuids,
  required Set<String> locallyHiddenGuids,
  required Set<String> locallyKnownGuids,
}) {
  final toHide = serverDeletedGuids
      .where((guid) => locallyKnownGuids.contains(guid) && !locallyHiddenGuids.contains(guid))
      .toSet();
  final toRestore = locallyHiddenGuids
      .where((guid) => locallyKnownGuids.contains(guid) && !serverDeletedGuids.contains(guid))
      .toSet();

  return RecoverableMessageActions(toHide: toHide, toRestore: toRestore);
}

/// Brings locally stored messages back in line with Apple's Recently Deleted
/// folder after the client has been offline.
///
/// The live `message-deleted` / `message-restored` events cover everything that
/// happens while connected; this covers the gap, the same way
/// ChatStateReconciler does for chats.
class RecoverableMessageReconciler {
  static Future<void> run() async {
    try {
      final response = await HttpSvc.server.getRecoverableMessageSnapshot();
      final payload = response.data['data'];
      if (payload is! Map) return;

      final snapshot = parseRecoverableMessageSnapshot(payload.cast<String, dynamic>());
      if (snapshot.skipped) {
        Logger.warn(
          'Refusing to reconcile Recently Deleted (${snapshot.reason})',
          tag: 'RecoverableMessageReconciler',
        );
        return;
      }

      final serverDeleted = snapshot.allDeletedGuids;

      final hiddenQuery = Database.messages.query(Message_.dateDeleted.notNull()).build();
      final hidden = hiddenQuery.find();
      hiddenQuery.close();
      final locallyHidden = hidden.map((message) => message.guid!).toSet();

      // Only messages the device already holds can be hidden or restored.
      final knownGuids = {...locallyHidden};
      for (final guid in serverDeleted) {
        if (Message.findOne(guid: guid) != null) knownGuids.add(guid);
      }

      final actions = resolveRecoverableMessageActions(
        serverDeletedGuids: serverDeleted,
        locallyHiddenGuids: locallyHidden,
        locallyKnownGuids: knownGuids,
      );
      if (actions.isEmpty) return;

      for (final guid in actions.toHide) {
        await Message.softDelete(guid);
      }
      for (final guid in actions.toRestore) {
        await Message.restore(guid);
      }

      Logger.info(
        'Reconciled Recently Deleted: ${actions.toHide.length} hidden, ${actions.toRestore.length} restored',
        tag: 'RecoverableMessageReconciler',
      );
    } catch (error, trace) {
      // A server below Ventura answers with UNSUPPORTED_MACOS_VERSION, which is
      // expected rather than a fault. Either way the live events still work and
      // the next launch retries.
      Logger.warn('Failed to reconcile Recently Deleted',
          error: error, trace: trace, tag: 'RecoverableMessageReconciler');
    }
  }
}
