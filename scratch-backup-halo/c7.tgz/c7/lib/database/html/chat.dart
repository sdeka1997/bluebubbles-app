import 'dart:async';

import 'package:bluebubbles/helpers/types/helpers/rcs_business_chat.dart';

import 'package:bluebubbles/services/backend/interfaces/chat_interface.dart';
import 'package:bluebubbles/utils/logger/logger.dart';
import 'package:bluebubbles/helpers/helpers.dart';
import 'package:bluebubbles/database/html/attachment.dart';
import 'package:bluebubbles/database/html/handle.dart';
import 'package:bluebubbles/database/html/message.dart';
import 'package:bluebubbles/services/services.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';

String getFullChatTitle(Chat _chat) {
  String? title = "";
  if (isNullOrEmpty(_chat.displayName)) {
    List<String> titles = [];
    for (int i = 0; i < _chat.participants.length; i++) {
      // ignore: argument_type_not_assignable, return_of_invalid_type, invalid_assignment, for_in_of_invalid_element_type
      String? name = _chat.participants[i].displayName;

      if (_chat.participants.length > 1 && !name.isPhoneNumber) {
        name = name.trim().split(" ")[0];
      } else {
        name = name.trim();
      }

      titles.add(name);
    }

    if (titles.isEmpty) {
      title = _chat.chatIdentifier;
    } else if (titles.length == 1) {
      title = titles[0];
    } else if (titles.length <= 4) {
      title = titles.join(", ");
      int pos = title.lastIndexOf(", ");
      if (pos != -1) title = "${title.substring(0, pos)} & ${title.substring(pos + 2)}";
    } else {
      title = titles.sublist(0, 3).join(", ");
      title = "$title & ${titles.length - 3} others";
    }
  } else {
    title = _chat.displayName;
  }

  return title!;
}

class Chat {
  int? id;
  String guid;
  String? chatIdentifier;
  String? serviceName;
  String? groupId;
  // Messages' first group id and every old one; copies of one conversation
  // share at least one. Null when the server predates them.
  String? originalGroupId;
  List<String>? legacyGroupIds;
  // Name after the newest rename; "" when it was cleared, null if never renamed.
  String? latestGroupTitle;
  // Chats with the same key show as one thread; set by assignThreadKeys.
  String? threadKey;
  bool? isArchived;
  String? muteType;
  String? muteArgs;
  bool? isPinned;
  bool? hasUnreadMessage;
  String? title;

  String? displayName;
  List<Handle> participants = [];
  bool? autoSendReadReceipts = true;
  bool? autoSendTypingIndicators = true;
  String? textFieldText;
  List<String> textFieldAttachments = [];
  Message? _latestMessage;

  /// Non-relation backing for web (no ObjectBox). Mirrors the IO chat API.
  Message? get dbLatestMessage => _latestMessage;
  DateTime? dbOnlyLatestMessageDate;

  void setLatestMessage(Message m) {
    _latestMessage = m;
    dbOnlyLatestMessageDate = m.dateCreated;
  }

  DateTime? dateDeleted;
  int? style;
  bool lockChatName;
  bool lockChatIcon;
  String? lastReadMessageGuid;
  String? customThemeLight;
  String? customThemeDark;

  final RxnString _customAvatarPath = RxnString();
  String? get customAvatarPath => _customAvatarPath.value;
  set customAvatarPath(String? s) => _customAvatarPath.value = s;
  void refreshCustomAvatar(String s) {
    _customAvatarPath.value = null;
    _customAvatarPath.value = s;
  }

  final RxnString _customBackgroundPath = RxnString();
  String? get customBackgroundPath => _customBackgroundPath.value;
  set customBackgroundPath(String? s) => _customBackgroundPath.value = s;

  final RxnInt _pinIndex = RxnInt();
  int? get pinIndex => _pinIndex.value;
  set pinIndex(int? i) => _pinIndex.value = i;

  final List<Handle> handles = [];

  Chat({
    this.id,
    required this.guid,
    this.chatIdentifier,
    this.serviceName,
    this.groupId,
    this.originalGroupId,
    this.legacyGroupIds,
    this.latestGroupTitle,
    this.threadKey,
    this.isArchived = false,
    this.isPinned = false,
    this.muteType,
    this.muteArgs,
    this.hasUnreadMessage = false,
    this.displayName,
    String? customAvatar,
    int? pinnedIndex,
    List<Handle>? participants,
    Message? latestMessage,
    this.autoSendReadReceipts = true,
    this.autoSendTypingIndicators = true,
    this.textFieldText,
    this.textFieldAttachments = const [],
    this.dateDeleted,
    this.style,
    this.lockChatName = false,
    this.lockChatIcon = false,
    this.lastReadMessageGuid,
    this.customThemeLight,
    this.customThemeDark,
    String? customBackground,
  }) {
    customAvatarPath = customAvatar;
    customBackgroundPath = customBackground;
    pinIndex = pinnedIndex;
    if (textFieldAttachments.isEmpty) textFieldAttachments = [];
    this.participants = participants ?? [];
    if (latestMessage != null) dbOnlyLatestMessageDate ??= latestMessage.dateCreated;
  }

  factory Chat.fromMap(Map<String, dynamic> json) {
    final message = json['lastMessage'] != null ? Message.fromMap(json['lastMessage']) : null;
    return Chat(
      id: json["ROWID"] ?? json["id"],
      guid: json["guid"],
      chatIdentifier: json["chatIdentifier"],
      serviceName: json["serviceName"],
      groupId: json["groupId"],
      originalGroupId: json["originalGroupId"],
      legacyGroupIds: (json["legacyGroupIds"] as List?)?.map((e) => e.toString()).toList(),
      latestGroupTitle: json["latestGroupTitle"],
      threadKey: json["threadKey"],
      isArchived: json['isArchived'] ?? false,
      muteType: json["muteType"],
      muteArgs: json["muteArgs"],
      isPinned: json["isPinned"] ?? false,
      hasUnreadMessage: json["hasUnreadMessage"] ?? false,
      latestMessage: message,
      displayName: json["displayName"],
      customAvatar: json['_customAvatarPath'],
      customBackground: json['_customBackgroundPath'],
      pinnedIndex: json['_pinIndex'],
      participants: (json['participants'] as List? ?? []).map((e) => Handle.fromMap(e)).toList(),
      autoSendReadReceipts: json["autoSendReadReceipts"],
      autoSendTypingIndicators: json["autoSendTypingIndicators"],
      dateDeleted: parseDate(json["dateDeleted"]),
      style: json["style"],
      lockChatName: json["lockChatName"] ?? false,
      lockChatIcon: json["lockChatIcon"] ?? false,
      lastReadMessageGuid: json["lastReadMessageGuid"],
      customThemeLight: json["customThemeLight"],
      customThemeDark: json["customThemeDark"],
    );
  }

  Chat save({
    bool updateMuteType = false,
    bool updateMuteArgs = false,
    bool updateIsPinned = false,
    bool updatePinIndex = false,
    bool updateIsArchived = false,
    bool updateHasUnreadMessage = false,
    bool updateAutoSendReadReceipts = false,
    bool updateAutoSendTypingIndicators = false,
    bool updateCustomAvatarPath = false,
    bool updateTextFieldText = false,
    bool updateTextFieldAttachments = false,
    bool updateDisplayName = false,
    bool updateDateDeleted = false,
    bool updateLockChatName = false,
    bool updateLockChatIcon = false,
    bool updateLastReadMessageGuid = false,
  }) {
    // ignore: argument_type_not_assignable, return_of_invalid_type, invalid_assignment, for_in_of_invalid_element_type
    WebListeners.notifyChat(this);
    return this;
  }

  Chat changeName(String? name) {
    displayName = name;
    return this;
  }

  /// The group's name as Messages shows it: the newest rename, where an empty
  /// rename means the name was removed. Messages' stored name can lag behind
  /// that. A name set on this phone still wins.
  String? get currentName => lockChatName ? displayName : latestGroupTitle ?? displayName;

  /// Get a chat's title
  String getTitle() {
    if (isNullOrEmpty(currentName)) {
      title = getChatCreatorSubtitle();
    } else {
      title = currentName;
    }
    return title!;
  }

  /// Get a chat's title
  String getChatCreatorSubtitle() {
    // generate names for group chats or DMs
    List<String> titles =
        participants.map((e) => e.displayName.trim().split(isGroup ? " " : String.fromCharCode(65532)).first).toList();
    if (titles.isEmpty) {
      if (chatIdentifier!.startsWith("urn:biz")) {
        return "Business Chat";
      }
      return chatIdentifier!;
    } else if (titles.length == 1) {
      return titles[0];
    } else if (titles.length <= 4) {
      final _title = titles.join(", ");
      int pos = _title.lastIndexOf(", ");
      if (pos != -1) {
        return "${_title.substring(0, pos)} & ${_title.substring(pos + 2)}";
      } else {
        return _title;
      }
    } else {
      final _title = titles.take(3).join(", ");
      return "$_title & ${titles.length - 3} others";
    }
  }

  bool shouldMuteNotification(Message? message) {
    if (SettingsSvc.settings.filterUnknownSenders.value &&
        participants.length == 1 &&
        participants[0].contacts.isEmpty) {
      return true;
    } else if (SettingsSvc.settings.globalTextDetection.value.isNotEmpty) {
      List<String> text = SettingsSvc.settings.globalTextDetection.value.split(",");
      for (String s in text) {
        if (message?.text?.toLowerCase().contains(s.toLowerCase()) ?? false) {
          return false;
        }
      }
      return true;
    } else if (muteType == "mute") {
      return true;
    } else if (muteType == "mute_individuals") {
      List<String> individuals = muteArgs!.split(",");
      return individuals.contains(message?.handle?.address ?? "");
    } else if (muteType == "temporary_mute") {
      DateTime time = DateTime.parse(muteArgs!);
      bool shouldMute = DateTime.now().toLocal().difference(time).inSeconds.isNegative;
      if (!shouldMute) {
        toggleMute(false);
        muteType = null;
        muteArgs = null;
        save();
      }
      return shouldMute;
    } else if (muteType == "text_detection") {
      List<String> text = muteArgs!.split(",");
      for (String s in text) {
        if (message?.text?.toLowerCase().contains(s.toLowerCase()) ?? false) {
          return false;
        }
      }
      return true;
    }
    return !SettingsSvc.settings.notifyReactions.value &&
        ReactionTypes.checkReactionType(message?.associatedMessageType);
  }

  static void unDelete(Chat chat) {
    return;
  }

  static void softDelete(Chat chat) {
    return;
  }

  Chat toggleHasUnread(bool hasUnread,
      {bool force = false, bool clearLocalNotifications = true, bool privateMark = true}) {
    if (hasUnreadMessage == hasUnread && !force) return this;
    if (!ChatsSvc.isChatActive(guid) || !hasUnread || force) {
      hasUnreadMessage = hasUnread;
      save(updateHasUnreadMessage: true);
    }

    try {
      if (privateMark &&
          SettingsSvc.settings.enablePrivateAPI.value &&
          SettingsSvc.settings.privateMarkChatAsRead.value) {
        if (!hasUnread && autoSendReadReceipts!) {
          HttpSvc.chat.markRead(guid);
        } else if (hasUnread) {
          HttpSvc.chat.markUnread(guid);
        }
      }
    } catch (_) {}

    return this;
  }

  Future<Chat> addMessage(Message message,
      {bool changeUnreadStatus = true, bool checkForMessageText = true, bool clearNotificationsIfFromMe = true}) async {
    // Save the message
    Message? latest = _latestMessage;
    Message? newMessage;

    try {
      newMessage = message.save(chat: this);
    } catch (ex, stacktrace) {
      newMessage = Message.findOne(guid: message.guid);
      if (newMessage == null) {
        Logger.error("Failed to add message (GUID: ${message.guid}) to chat (GUID: $guid)",
            error: ex, trace: stacktrace);
      }
    }
    bool isNewer = false;

    // If the message was saved correctly, update this chat's latestMessage info,
    // but only if the incoming message's date is newer
    if ((newMessage?.id != null || kIsWeb) && checkForMessageText) {
      isNewer = message.dateCreated!.isAfter(latest?.dateCreated ?? DateTime.fromMillisecondsSinceEpoch(0)) ||
          (message.guid != latest?.guid && message.dateCreated == latest?.dateCreated);
      if (isNewer) {
        setLatestMessage(message);
        dateDeleted = null;
        // ignore: argument_type_not_assignable, return_of_invalid_type, invalid_assignment, for_in_of_invalid_element_type
        await ChatsSvc.addChat(this);
      }
    }

    // Save any attachments
    for (Attachment? attachment in message.attachments) {
      attachment!.save(newMessage);
    }

    // Save the chat.
    // This will update the latestMessage info as well as update some
    // other fields that we want to "mimic" from the server
    save();

    // If the incoming message was newer than the "last" one, set the unread status accordingly
    if (checkForMessageText && changeUnreadStatus && isNewer) {
      // If the message is from me, mark it unread
      // If the message is not from the same chat as the current chat, mark unread
      if (message.isFromMe!) {
        toggleHasUnread(false, clearLocalNotifications: clearNotificationsIfFromMe, force: ChatsSvc.isChatActive(guid));
      } else if (!ChatsSvc.isChatActive(guid)) {
        toggleHasUnread(true);
      }
    }

    // If the message is for adding or removing participants,
    // we need to ensure that all of the chat participants are correct by syncing with the server
    if (message.isParticipantEvent && checkForMessageText) {
      serverSyncParticipants();
    }

    // Return the current chat instance (with updated vals)
    return this;
  }

  void serverSyncParticipants() async {
    // Send message to server to get the participants
    // Send message to server to get the participants
    final chat = await ChatsSvc.fetchChat(guid);
    if (chat != null) {
      await chat.saveAsync();
    }
  }

  static int? count() {
    return null;
  }

  static List<Attachment> getAttachments(Chat chat, {int offset = 0, int limit = 25}) {
    return [];
  }

  Future<List<Attachment>> getAttachmentsAsync() async {
    return [];
  }

  static List<Message> getMessages(Chat chat,
      {int offset = 0, int limit = 25, bool includeDeleted = false, bool getDetails = false}) {
    return [];
  }

  static Future<List<Message>> getMessagesAsync(Chat chat,
      {int offset = 0, int limit = 25, bool includeDeleted = false}) async {
    return [];
  }

  void webSyncParticipants() {
    // ignore: argument_type_not_assignable, return_of_invalid_type, invalid_assignment, for_in_of_invalid_element_type
    participants = ChatsSvc.webCachedHandles
        .where((e) => participants.map((e2) => e2.address).contains(e.address))
        .cast<Handle>()
        .toList();
  }

  Chat addParticipant(Handle participant) {
    participants.add(participant);
    _deduplicateParticipants();
    return this;
  }

  Chat removeParticipant(Handle participant) {
    participants.removeWhere((element) => participant.id == element.id);
    _deduplicateParticipants();
    return this;
  }

  void _deduplicateParticipants() {
    if (participants.isEmpty) return;
    final ids = participants.map((e) => e.address).toSet();
    participants.retainWhere((element) => ids.remove(element.address));
  }

  Chat togglePin(bool isPinned) {
    if (id == null) return this;
    this.isPinned = isPinned;
    _pinIndex.value = null;
    save();
    // ignore: argument_type_not_assignable, return_of_invalid_type, invalid_assignment, for_in_of_invalid_element_type
    ChatsSvc.updateChat(this);
    return this;
  }

  Chat toggleMute(bool isMuted) {
    if (id == null) return this;
    muteType = isMuted ? "mute" : null;
    muteArgs = null;
    save();
    // ignore: argument_type_not_assignable, return_of_invalid_type, invalid_assignment, for_in_of_invalid_element_type
    ChatsSvc.updateChat(this);
    return this;
  }

  Chat toggleArchived(bool isArchived) {
    if (id == null) return this;
    this.isArchived = isArchived;
    save();
    // ignore: argument_type_not_assignable, return_of_invalid_type, invalid_assignment, for_in_of_invalid_element_type
    ChatsSvc.updateChat(this);
    return this;
  }

  Chat toggleAutoRead(bool? autoSendReadReceipts) {
    if (id == null) return this;
    this.autoSendReadReceipts = autoSendReadReceipts;
    save(updateAutoSendReadReceipts: true);
    if (autoSendReadReceipts ?? SettingsSvc.settings.privateMarkChatAsRead.value) {
      HttpSvc.chat.markRead(guid);
    }
    return this;
  }

  Chat toggleAutoType(bool? autoSendTypingIndicators) {
    if (id == null) return this;
    this.autoSendTypingIndicators = autoSendTypingIndicators;
    save(updateAutoSendTypingIndicators: true);
    if (!(autoSendTypingIndicators ?? SettingsSvc.settings.privateSendTypingIndicators.value)) {
      unawaited(ChatInterface.stopTyping(chatGuid: guid));
    }
    return this;
  }

  static Future<Chat?> findOneWeb({String? guid, String? chatIdentifier}) async {
    if (guid != null) {
      return ChatsSvc.findChatByGuid(guid) as Chat;
    } else if (chatIdentifier != null) {
      return ChatsSvc.findChatByChatIdentifier(chatIdentifier) as Chat;
    }
    return null;
  }

  static Chat? findOne({String? guid, String? chatIdentifier}) {
    return null;
  }

  static List<Chat> getChats({int limit = 15, int offset = 0}) {
    throw Exception("Use socket to get chats on Web!");
  }

  static Future<List<Chat>> syncLatestMessages(List<Chat> chats, bool toggleUnread) async {
    return chats;
  }

  static Future<List<Chat>> bulkSyncChats(List<Chat> chats) async {
    return chats;
  }

  static Future<List<Message>> bulkSyncMessages(Chat chat, List<Message> messages) async {
    return messages;
  }

  void clearTranscript() {
    return;
  }

  ChatServiceType get service => ChatServiceType.fromServer(serviceName, guid);

  bool get isTextForwarding => service == ChatServiceType.sms;

  bool get isSMS => service == ChatServiceType.sms;

  bool get isIMessage => service == ChatServiceType.iMessage;

  /// Composer placeholder for the service the conversation is using now: the
  /// newest message's sender service when known, otherwise this chat's own.
  String composerLabel([Message? latestMessage]) =>
      ChatServiceType.current(service, latestMessageService: latestMessage?.service ?? latestMessage?.getHandle()?.service).composerLabel;

  bool get isGroup => participants.length > 1 || style == 43;

  /// An RCS business chat, which stays on the iPhone.
  bool get isRcsBusiness => isRcsBusinessChat(chatIdentifier: chatIdentifier, guid: guid);

  Chat merge(Chat other) {
    id ??= other.id;
    _customAvatarPath.value ??= other._customAvatarPath.value;
    _pinIndex.value ??= other._pinIndex.value;
    autoSendReadReceipts ??= other.autoSendReadReceipts;
    autoSendTypingIndicators ??= other.autoSendTypingIndicators;
    textFieldText ??= other.textFieldText;
    if (textFieldAttachments.isEmpty) {
      textFieldAttachments.addAll(other.textFieldAttachments);
    }
    chatIdentifier ??= other.chatIdentifier;
    groupId = other.groupId ?? groupId;
    originalGroupId = other.originalGroupId ?? originalGroupId;
    legacyGroupIds = other.legacyGroupIds ?? legacyGroupIds;
    latestGroupTitle = other.latestGroupTitle ?? latestGroupTitle;
    displayName ??= other.displayName;
    if (handles.isEmpty) {
      handles.addAll(other.handles);
    }
    if (participants.isEmpty) {
      participants.addAll(other.participants);
    }
    hasUnreadMessage ??= other.hasUnreadMessage;
    isArchived ??= other.isArchived;
    isPinned ??= other.isPinned;
    if (_latestMessage == null && other._latestMessage != null) setLatestMessage(other._latestMessage!);
    muteArgs ??= other.muteArgs;
    title ??= other.title;
    dateDeleted ??= other.dateDeleted;
    style ??= other.style;
    return this;
  }

  static int sort(Chat? a, Chat? b) {
    // If they both are pinned & ordered, reflect the order
    if (a!.isPinned! && b!.isPinned! && a.pinIndex != null && b.pinIndex != null) {
      return a.pinIndex!.compareTo(b.pinIndex!);
    }

    // If b is pinned & ordered, but a isn't either pinned or ordered, return accordingly
    if (b!.isPinned! && b.pinIndex != null && (!a.isPinned! || a.pinIndex == null)) return 1;
    // If a is pinned & ordered, but b isn't either pinned or ordered, return accordingly
    if (a.isPinned! && a.pinIndex != null && (!b.isPinned! || b.pinIndex == null)) return -1;

    // Compare when one is pinned and the other isn't
    if (!a.isPinned! && b.isPinned!) return 1;
    if (a.isPinned! && !b.isPinned!) return -1;

    // Compare the last message dates (negate to sort newest first)
    return -((a.dbOnlyLatestMessageDate ?? DateTime.fromMillisecondsSinceEpoch(0))
        .compareTo(b.dbOnlyLatestMessageDate ?? DateTime.fromMillisecondsSinceEpoch(0)));
  }

  static Future<void> getIcon(Chat c, {bool force = false}) async {}

  Map<String, dynamic> toMap() => {
        "ROWID": id,
        "guid": guid,
        "chatIdentifier": chatIdentifier,
        "serviceName": serviceName,
        "groupId": groupId,
        "originalGroupId": originalGroupId,
        "legacyGroupIds": legacyGroupIds,
        "latestGroupTitle": latestGroupTitle,
        "threadKey": threadKey,
        "isArchived": isArchived!,
        "muteType": muteType,
        "muteArgs": muteArgs,
        "isPinned": isPinned!,
        "displayName": displayName,
        "participants": participants.map((item) => item.toMap()).toList(),
        "hasUnreadMessage": hasUnreadMessage!,
        "_customAvatarPath": _customAvatarPath.value,
        "_customBackgroundPath": _customBackgroundPath.value,
        "_pinIndex": _pinIndex.value,
        "autoSendReadReceipts": autoSendReadReceipts!,
        "autoSendTypingIndicators": autoSendTypingIndicators!,
        "dateDeleted": dateDeleted?.millisecondsSinceEpoch,
        "style": style,
        "lockChatName": lockChatName,
        "lockChatIcon": lockChatIcon,
        "lastReadMessageGuid": lastReadMessageGuid,
        "customThemeLight": customThemeLight,
        "customThemeDark": customThemeDark,
      };
}
