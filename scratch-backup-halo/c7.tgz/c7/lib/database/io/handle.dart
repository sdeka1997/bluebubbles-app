import 'dart:async';

import 'package:bluebubbles/database/database.dart';
import 'package:bluebubbles/database/models.dart';
import 'package:bluebubbles/services/backend/interfaces/handle_interface.dart';
import 'package:bluebubbles/helpers/helpers.dart';
import 'package:dice_bear/dice_bear.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
// (needed when generating objectbox model code)
// ignore: unnecessary_import
import 'package:objectbox/objectbox.dart';
import 'package:bluebubbles/database/io/relations.dart' show RelList;
import 'package:bluebubbles/models/models.dart' show HandleLookupKey;

/// The Apple ROWID a handle carries, if it came straight from the server.
///
/// A handle rebuilt from the local database (it has a local id) may hold a
/// ROWID left over from a previous Apple database, so it reports nothing.
int? serverReportedRowId(Handle handle) => handle.id == null ? handle.originalROWID : null;

/// Points each local handle at the ROWID the server reported for it, and clears
/// that ROWID from any other handle in [holders] still using it.
///
/// ROWIDs are only unique within one Apple chat.db, so once the server's
/// database is replaced a local handle can hold a ROWID that now belongs to
/// someone else. Messages are never relinked here: older ones legitimately
/// carry ROWIDs from the previous database. Returns the handles to save.
List<Handle> adoptServerRowIds(List<(Handle, int)> reported, List<Handle> holders) {
  final changed = <String, Handle>{};
  final rowIdByHandle = <String, int>{};
  for (final (handle, rowId) in reported) {
    rowIdByHandle[handle.uniqueAddressAndService] = rowId;
    if (handle.originalROWID != rowId) {
      handle.originalROWID = rowId;
      changed[handle.uniqueAddressAndService] = handle;
    }
  }
  final reportedRowIds = rowIdByHandle.values.toSet();
  for (final holder in holders) {
    final rowId = holder.originalROWID;
    if (rowId == null || !reportedRowIds.contains(rowId)) continue;
    if (rowIdByHandle.containsKey(holder.uniqueAddressAndService)) continue;
    holder.originalROWID = null;
    changed[holder.uniqueAddressAndService] = holder;
  }
  return changed.values.toList();
}

/// Runs [adoptServerRowIds] against the handles in [box] holding a reported
/// ROWID and saves every handle it changed. Must run inside a write transaction.
void adoptServerRowIdsInBox(Box<Handle> box, List<(Handle, int)> reported) {
  if (reported.isEmpty) return;
  final query = box.query(Handle_.originalROWID.oneOf(reported.map((r) => r.$2).toList())).build();
  final holders = query.find();
  query.close();
  final changed = adoptServerRowIds(reported, holders);
  if (changed.isNotEmpty) box.putMany(changed);
}

@Entity()
class Handle {
  int? id;
  int? originalROWID;
  @Unique()
  String uniqueAddressAndService;
  String address;
  String? formattedAddress;
  String service;
  String? country;
  String? defaultEmail;
  String? defaultPhone;

  String? color;

  // N:M Relationship to ContactV2 (new contact service)
  // This is a backlink - ContactV2 owns the relationship
  @Backlink('handles')
  final contactsV2 = RelList<ContactV2>();

  @Transient()
  Widget? _fakeAvatar;

  @Transient()
  Widget get fakeAvatar {
    if (_fakeAvatar != null) return _fakeAvatar!;
    // Pick a random background color from the hex list: randomAvatarBackgroundColors
    final backgroundColor = randomAvatarBackgroundColors.randomChoice();

    Avatar _avatar = DiceBearBuilder(
      seed: address,
      sprite: DiceBearStyle.miniavs,
      // Random light color scheme with a custom background color to prevent white backgrounds on light mode
      backgroundColor: HexColor(backgroundColor),
    ).build();
    _fakeAvatar = _avatar.toImage();
    return _fakeAvatar!;
  }

  @Transient()
  String get displayName {
    if (address.startsWith("urn:biz")) return "Business";
    if (!kIsWeb && contactsV2.isNotEmpty) {
      // Prioritize native contacts, but fall back to any contact if no native ones exist (should be rare)
      final firstNativeContact = contactsV2.where((c) => c.isNative).firstOrNull;
      final nativeNickname = firstNativeContact?.nickname;
      if (!isNullOrEmpty(nativeNickname)) return nativeNickname!;

      final nativeDisplayName = firstNativeContact?.displayName;
      if (!isNullOrEmpty(nativeDisplayName)) return nativeDisplayName!;

      final computedDisplayName = contactsV2.first.computedDisplayName;
      if (!isNullOrEmpty(computedDisplayName)) return computedDisplayName;
    }

    // Formatted address should be filled out by sync. If it's missing,
    // format on demand so UI callers still get a readable phone number.
    return address.contains("@") ? address : (formattedAddress ?? formatPhoneNumber(address));
  }

  @Transient()
  String get reactionDisplayName {
    if (address.startsWith("urn:biz")) return "Business";
    if (!kIsWeb && contactsV2.isNotEmpty) {
      // Like the iPhone: the card's nickname, else its first name, else its
      // name. Cards now come from the Mac's Apple Contacts rather than the
      // phone, so any card counts, a phone one first if there is one.
      final card = contactsV2.where((c) => c.isNative).firstOrNull ?? contactsV2.first;
      if (!isNullOrEmpty(card.nickname)) return card.nickname!;
      if (!isNullOrEmpty(card.firstName)) return card.firstName!;
      if (!isNullOrEmpty(card.computedDisplayName)) return card.computedDisplayName;
    }

    // For reactions, we want to show the formatted address for phone numbers, but the regular address for emails
    return address.contains("@") ? address : (formattedAddress ?? address);
  }

  @Transient()
  String get shortName {
    return contactsV2.isNotEmpty ? reactionDisplayName.firstWord : reactionDisplayName;
  }

  @Transient()
  String? get initials {
    if (address.startsWith("urn:biz")) return null;

    // Check ContactV2 first for initials
    if (!kIsWeb && contactsV2.isNotEmpty) {
      final contactV2Initials = contactsV2.first.initials;
      if (contactV2Initials != null) return contactV2Initials;
    }

    // Split by space/dash/underscore and take first alpha of first + last word
    final parts = displayName.trim().split(RegExp(r'[ \-_]'));
    if (parts.length == 1) return parts[0].firstAlpha?.toUpperCase();

    final firstPart = (parts.first.firstAlpha ?? '').toUpperCase();
    final lastPart = (parts.last.firstAlpha ?? '').toUpperCase();

    return (firstPart + lastPart).isEmpty ? null : firstPart + lastPart;
  }

  Handle({
    this.id,
    this.originalROWID,
    this.address = "",
    this.formattedAddress,
    this.service = 'iMessage',
    this.uniqueAddressAndService = "",
    this.country,
    this.color,
    this.defaultEmail,
    this.defaultPhone,
  }) {
    if (service.isEmpty) {
      service = 'iMessage';
    }
    if (uniqueAddressAndService.isEmpty) {
      uniqueAddressAndService = "$address/$service";
    }
  }

  factory Handle.fromMap(Map<String, dynamic> json) => Handle(
        id: json["ROWID"] ?? json["id"],
        // Server participants payloads carry the sender ROWID under "ROWID" and
        // omit "originalROWID". Falling back preserves that ROWID as the
        // originalROWID so Message.handleId → Handle lookups succeed for
        // brand-new chats synced via bulkSyncChats.
        originalROWID: json["originalROWID"] ?? json["ROWID"],
        address: json["address"],
        formattedAddress: json["formattedAddress"],
        service: json["service"] ?? "iMessage",
        uniqueAddressAndService: json["uniqueAddrAndService"] ?? "${json["address"]}/${json["service"] ?? "iMessage"}",
        country: json["country"],
        color: json["color"],
        defaultPhone: json["defaultPhone"],
        defaultEmail: json["defaultEmail"],
      );

  /// Formats and sets the formattedAddress field if not already set.
  ///
  /// For emails and business chats (urn:biz), uses the address as-is.
  /// For phone numbers, formats them using the formatPhoneNumber helper.
  ///
  /// This should be called in isolate actions before saving handles to the database.
  Future<void> updateFormattedAddress() async {
    if (!isNullOrEmpty(formattedAddress)) return;

    if (address.contains('@') || address.startsWith('urn:biz')) {
      formattedAddress = address;
    } else {
      formattedAddress = formatPhoneNumber(address);
    }
  }

  /// Save a single handle - prefer [bulkSave] for multiple handles rather
  /// than iterating through them
  Handle save({bool updateColor = false, matchOnOriginalROWID = false}) {
    if (kIsWeb) return this;
    Database.runInTransaction(TxMode.write, () {
      Handle? existing;
      if (matchOnOriginalROWID) {
        existing = Handle.findOne(originalROWID: originalROWID);
      } else {
        existing = Handle.findOne(addressAndService: HandleLookupKey(address, service));
      }

      if (existing != null) {
        id = existing.id;
        originalROWID ??= existing.originalROWID;
      }
      // Contact matching is now handled automatically by ContactServiceV2
      if (!updateColor) {
        color = existing?.color ?? color;
      }
      try {
        id = Database.handles.put(this);
      } on UniqueViolationException catch (_) {}
    });
    return this;
  }

  /// Save a single handle asynchronously (non-blocking)
  Future<Handle> saveAsync({bool updateColor = false, matchOnOriginalROWID = false}) async {
    if (kIsWeb) return this;

    final savedHandle = await HandleInterface.saveHandleAsync(
      handleData: toMap(),
      updateColor: updateColor,
      matchOnOriginalROWID: matchOnOriginalROWID,
    );

    // Update this handle with the saved data
    id = savedHandle.id;
    color = savedHandle.color;
    originalROWID = savedHandle.originalROWID;

    return this;
  }

  /// Save a list of handles
  static List<Handle> bulkSave(List<Handle> handles, {matchOnOriginalROWID = false}) {
    Database.runInTransaction(TxMode.write, () {
      /// Match existing to the handles to save, where possible
      for (Handle h in handles) {
        Handle? existing;
        if (matchOnOriginalROWID) {
          existing = Handle.findOne(originalROWID: h.originalROWID);
        } else {
          existing = Handle.findOne(addressAndService: HandleLookupKey(h.address, h.service));
        }

        if (existing != null) {
          h.id = existing.id;
          h.originalROWID ??= existing.originalROWID;
        }
        // Contact matching is now handled automatically by ContactServiceV2
      }

      List<int> insertedIds = Database.handles.putMany(handles);
      for (int i = 0; i < insertedIds.length; i++) {
        handles[i].id = insertedIds[i];
      }
    });

    return handles;
  }

  /// Save a list of handles asynchronously (non-blocking)
  static Future<List<Handle>> bulkSaveAsync(List<Handle> handles, {matchOnOriginalROWID = false}) async {
    if (kIsWeb) return handles;
    if (handles.isEmpty) return handles;

    final savedHandles = await HandleInterface.bulkSaveHandlesAsync(
      handlesData: handles.map((e) => e.toMap()).toList(),
      matchOnOriginalROWID: matchOnOriginalROWID,
    );

    // Update the handles with saved data
    for (int i = 0; i < handles.length; i++) {
      if (i < savedHandles.length) {
        handles[i].id = savedHandles[i].id;
        handles[i].color = savedHandles[i].color;
        handles[i].originalROWID = savedHandles[i].originalROWID;
      }
    }

    return handles;
  }

  /// Permanently deletes a handle by its local database [id]. Used by the
  /// Developer Tools "Handle Auditing" panel to purge orphaned/unrecoverable
  /// handle records. Does not clean up references from other entities (Chat
  /// participants, Message.handleRelation) — those simply resolve to null
  /// afterwards, matching how deleteChat's handle cleanup already behaves.
  ///
  /// A single-row delete is cheap enough to run directly on the calling
  /// thread — no need to round-trip through the isolate for this.
  static void delete(int id) {
    if (kIsWeb) return;
    Database.runInTransaction(TxMode.write, () {
      Database.handles.remove(id);
    });
  }

  Handle updateDefaultPhone(String newPhone) {
    defaultPhone = newPhone;
    unawaited(saveAsync());
    return this;
  }

  Handle updateDefaultEmail(String newEmail) {
    defaultEmail = newEmail;
    unawaited(saveAsync());
    return this;
  }

  static Handle? findOne({int? id, int? originalROWID, HandleLookupKey? addressAndService}) {
    if (kIsWeb || id == 0) return null;
    if (id != null) {
      final handle = Database.handles.get(id) ?? Handle.findOne(originalROWID: id);
      return handle;
    } else if (originalROWID != null) {
      final query = Database.handles.query(Handle_.originalROWID.equals(originalROWID)).build();
      query.limit = 1;
      final result = query.findFirst();
      query.close();
      return result;
    } else if (addressAndService != null) {
      final query = Database.handles
          .query(Handle_.address.equals(addressAndService.address) & Handle_.service.equals(addressAndService.service))
          .build();
      query.limit = 1;
      final result = query.findFirst();
      query.close();
      return result;
    }
    return null;
  }

  static Future<Handle?> findOneAsync({int? id, int? originalROWID, HandleLookupKey? addressAndService}) async {
    if (kIsWeb || id == 0) return null;

    return await HandleInterface.findOneHandleAsync(
      id: id,
      originalROWID: originalROWID,
      address: addressAndService?.address,
      service: addressAndService?.service,
    );
  }

  static Handle merge(Handle handle1, Handle handle2) {
    handle1.id ??= handle2.id;
    handle1.originalROWID ??= handle2.originalROWID;
    handle1.color ??= handle2.color;
    handle1.country ??= handle2.country;
    handle1.formattedAddress ??= handle2.formattedAddress;
    if (isNullOrEmpty(handle1.defaultPhone)) {
      handle1.defaultPhone = handle2.defaultPhone;
    }
    if (isNullOrEmpty(handle1.defaultEmail)) {
      handle1.defaultEmail = handle2.defaultEmail;
    }

    return handle1;
  }

  /// Find a list of handles by the specified condition, or return all handles
  /// when no condition is specified
  static List<Handle> find({Condition<Handle>? cond}) {
    final query = Database.handles.query(cond).build();
    return query.find();
  }

  static Future<List<Handle>> findAsync({Condition<Handle>? cond}) async {
    if (kIsWeb) return [];

    // Note: For now, we don't serialize conditions for cross-isolate communication
    // This will return all handles. Future enhancement can add condition serialization.
    return await HandleInterface.findHandlesAsync();
  }

  Map<String, dynamic> toMap() {
    return {
      "ROWID": id,
      "originalROWID": originalROWID,
      "address": address,
      "formattedAddress": formattedAddress,
      "service": service,
      "uniqueAddrAndService": uniqueAddressAndService,
      "country": country,
      "color": color,
      "defaultPhone": defaultPhone,
      "defaultEmail": defaultEmail,
    };
  }
}
