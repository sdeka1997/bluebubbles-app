import 'package:bluebubbles/database/store/objectbox/objectbox_thread_store_helpers.dart' show listsThreadCondition;
import 'package:bluebubbles/database/database.dart';
import 'package:bluebubbles/database/models.dart';
import 'package:bluebubbles/helpers/backend/startup_tasks.dart';
import 'package:bluebubbles/utils/logger/logger.dart';

/// Migration that backfills [Chat.dbLatestMessage] and [Chat.dbOnlyLatestMessageDate]
/// for all existing chats by querying each chat's most recent non-deleted message.
class ChatLatestMessageMigration {
  static Future<void> migrate() async {
    try {
      Logger.info("Starting chat latest message migration...", tag: "DB-Migration");
      await _migrateChats();
      Logger.info("Chat latest message migration completed successfully", tag: "DB-Migration");
    } catch (e, stack) {
      Logger.error("Failed to complete chat latest message migration!", error: e, trace: stack, tag: "DB-Migration");
      rethrow;
    }
  }

  static Future<void> _migrateChats() async {
    const int batchSize = 100;
    final chatBox = Database.chats;
    final messageBox = Database.messages;

    final totalChats = chatBox.count();
    Logger.info("Processing $totalChats chats for latest message backfill...", tag: "DB-Migration");

    int processed = 0;

    while (processed < totalChats) {
      final batchQuery = chatBox.query().build()
        ..limit = batchSize
        ..offset = processed;
      final batch = batchQuery.find();
      batchQuery.close();

      if (batch.isEmpty) break;

      final chatsToUpdate = <Chat>[];
      for (final chat in batch) {
        if (chat.id == null) continue;

        // Find the most recent non-deleted message for this chat.
        final msgQuery = (messageBox.query(Message_.dateDeleted.isNull().and(listsThreadCondition))
              ..link(Message_.chat, Chat_.id.equals(chat.id!))
              ..order(Message_.dateCreated, flags: Order.descending))
            .build()
          ..limit = 1;
        final latest = msgQuery.findFirst();
        msgQuery.close();

        if (latest == null) continue;

        chat.dbLatestMessage.target = latest;
        chat.dbOnlyLatestMessageDate = latest.dateCreated;
        chatsToUpdate.add(chat);
      }

      if (chatsToUpdate.isNotEmpty) {
        chatBox.putMany(chatsToUpdate);
      }

      processed += batch.length;
      // the await is what gets this to the splash while the migration owns the isolate.
      await StartupTasks.setSplashProgress(processed / totalChats);
      Logger.info("Backfilled $processed / $totalChats chats...", tag: "DB-Migration");
    }
  }
}
