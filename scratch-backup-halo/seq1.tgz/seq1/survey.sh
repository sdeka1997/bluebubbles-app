#!/bin/bash
# Read-only survey on the Air for the sequoia1 build.
set -u
P="$HOME/BlueBubbles-v812-Package"
echo "== base asar"
shasum -a 256 "$P/app.custom.v8.12.19.asar"
find "$P/app.custom.v8.12.19.asar.unpacked" -type f | wc -l
find "$P/app.custom.v8.12.19.asar.unpacked" -type f | sed "s|$P/app.custom.v8.12.19.asar.unpacked/||" | sort
echo "== src"
cd /tmp/wseq-server
git rev-parse HEAD
git branch --show-current
git status --short --ignored
ls packages/server/dist 2>&1 | head
grep -n devEngines -A4 package.json | head
grep -n '"@noble/ciphers"\|"better-sqlite3"\|"electron"' package.json packages/server/package.json
echo "== helper"
shasum -a 256 packages/server/appResources/private-api/macos11/BlueBubblesHelper.dylib
cat packages/server/appResources/private-api/macos11/BlueBubblesHelper.dylib.md5 2>/dev/null; echo
ls -la packages/server/appResources/private-api/macos11/
find packages/server/appResources -type f | wc -l
echo "== git diff of appResources vs v8.12.19 base"
git diff --stat forkpush/deployed/server-v8.12.19 HEAD -- packages/server/appResources
echo "== webpack externals"
grep -n -i 'extern' -A6 packages/server/webpack.config.js 2>/dev/null | head -40
ls packages/server/
echo "== nix"
ls /nix/var/nix/profiles/default/bin | head
echo "== disk"
df -h ~
