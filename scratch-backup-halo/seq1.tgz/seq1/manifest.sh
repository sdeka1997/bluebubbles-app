#!/bin/bash
# Final appResources diff, manifest, and cleanup for sequoia1.
set -euo pipefail
S="$HOME/BlueBubbles-Staging"
DST="$S/BlueBubbles-Custom-sequoia1.app"
P="$HOME/BlueBubbles-v812-Package"
SRC="/tmp/wseq-server/packages/server/appResources"
R="$DST/Contents/Resources/appResources"
sha() { /usr/bin/shasum -a 256 "$1" | /usr/bin/cut -d' ' -f1; }
M="$S/SEQUOIA1-MANIFEST.txt"

echo "== source appResources vs staged appResources"
DIFF=$( (cd "$SRC" && find . -type f | sort) > /tmp/seq1-a; (cd "$R" && find . -type f | sort) > /tmp/seq1-b
  for f in $(sort -u /tmp/seq1-a /tmp/seq1-b); do
    if [ ! -e "$SRC/$f" ]; then echo "bundle-only  $f"
    elif [ ! -e "$R/$f" ]; then echo "source-only  $f"
    elif ! cmp -s "$SRC/$f" "$R/$f"; then echo "differs      $f"; fi
  done; rm -f /tmp/seq1-a /tmp/seq1-b)
echo "$DIFF"

cd /tmp/wseq-server
H="$R/private-api/macos11/BlueBubblesHelper.dylib"
{
cat <<EOF
BlueBubbles custom server — Sequoia test build "sequoia1"   (built $(date '+%Y-%m-%d %H:%M %Z'))
STATUS: STAGED, UNSIGNED. The bundle still carries the official WPV275H8W7 signature, which is now
INVALID (Info.plist/asar/appResources modified). Sign on bbsequoia before use. Not installed anywhere.

Source
  repo/branch      /tmp/wseq-server  sequoia/integration (local only — never push)
  HEAD             $(git rev-parse HEAD)
  parents          $(git log -1 --format=%P HEAD)
  contains         forkpush/deployed/server-v8.12.19 $(git rev-parse --short=8 forkpush/deployed/server-v8.12.19)
                   feat/rcs-service $(git rev-parse --short=8 feat/rcs-service)
                   feat/emoji-tapbacks $(git rev-parse --short=8 feat/emoji-tapbacks)
                   feat/sequoia-findmy $(git rev-parse --short=8 feat/sequoia-findmy)
  toolchain        Nix nodejs_22 22.23.3 / npm 10.9.9; npm ci --ignore-scripts (no devEngines strip needed)
  build note       Stock 'npm run build' FAILS: emoji-tapbacks 0b6da0ad set tsconfig include ["src","test"],
                   so ForkTsChecker type-checks test/*.ts (34 errors, all in test/). Built with an
                   out-of-tree wrapper (/tmp/seq1-webpack.prod.js) = the prod config with ForkTsChecker
                   pointed at a src-only tsconfig extending the repo's. Emit (babel-loader/terser) is
                   unchanged; src type-check passed with 0 errors. Source not modified.

main.js
  dist/main.js      $(sha packages/server/dist/main.js)
  dist/main.js.map  $(sha packages/server/dist/main.js.map)

ASAR
  base              $P/app.custom.v8.12.19.asar  b462b06d237a306f25194a4b22acd91b71296bfea3e39d5fa830cb91aa03913a (= production v8.12.19)
  output            $P/app.custom.sequoia1.asar  $(sha "$P/app.custom.sequoia1.asar")
  staged app.asar   $(sha "$DST/Contents/Resources/app.asar")
  ElectronAsarIntegrity  $(/usr/libexec/PlistBuddy -c 'Print :ElectronAsarIntegrity:Resources/app.asar:hash' "$DST/Contents/Info.plist")  (Info.plist == header hash, verified)
  repacker          $P/repack-sequoia1.js
  changes vs base   dist/main.js + dist/main.js.map swapped; node_modules/@noble/ciphers 1.3.0 added (131 files,
                    packed, byte-identical to /tmp/noble-scratch, no runtime deps); 11666 other files unchanged;
                    unpacked set identical (28 files: ngrok, node-mac-contacts, node-mac-permissions).
  better-sqlite3    8.7.0 already in base; build/Release/better_sqlite3.node is PACKED in the asar (not in
                    .unpacked) — same as official 1.9.9 and production; loads under Electron (verified).

Bundle   $DST
  base              official BlueBubbles 1.9.9 copied read-only from bbsequoia:/Applications/BlueBubbles.app
                    (official app.asar 889198e228a045d1bbc2ea9377dd6d5022373db34b3b012e674a9cf72ed6c438,
                     integrity 0672e2503d226eee7f2ed9a1abeb6832600bb5322408d13081179c007b4a4beb, Team WPV275H8W7;
                     strict codesign failed only on cloudflare.pid, as expected)
  helper (macos11)  $(sha "$H")  x86_64-only, unsigned (official was e1218eb0…, Developer-ID signed)
  helper .md5       $(tr -d '\n' < "$H.md5")  (matches md5 of dylib)

appResources changes (official bundle -> staged)
  replaced  private-api/macos11/BlueBubblesHelper.dylib (+ .md5)   rebuilt emoji helper, 0180e0f3
  added     private-api/macos11/BlueBubblesHelper.dylib.source.txt provenance note
  added     macos/tools/findmy-geocoder.js  e7c1ebaf5fd621ab9dda7a318bcba1cf61389420c32a9ae1cd9ed760b529c507 (#855; spawned by main.js)
  added     macos/icons/tray/icon-{dark,light}Template{,@2x}.png  (main.js AppTray loads icons/tray/*Template.png;
            official 1.9.9 only has macos/icons/tray-icon-{dark,light}.png)
  removed   macos/daemons/cloudflare/cloudflare.pid (runtime file)
  kept      official private-api/macos10/BlueBubblesHelper.dylib and macos11/BlueBubblesFaceTimeHelper.dylib
            (git copies differ in bytes from the signed official release; unchanged by the branches; production
            v8.12.19 also keeps the official ones)
  residual diff source-tree vs staged appResources:
$(echo "$DIFF" | sed 's/^/    /')

Markers verified in packed dist/main.js (repack-sequoia1.js; 33 checks)
  v8.12.19: swapnav/readsync-findmy-v812, CUSTOM_BUILD_UPDATE_DISABLED, BeaconStoreKey, chat-deleted,
    chat-state/snapshot, filename*=UTF-8, isFilteredAsSpam, message-deleted, message-restored,
    chat_recoverable_message_join, SMSCategory, newer_m.date > m.date, favorite_order,
    "Skipping FCM notification: the message is too large", findmy-geocoder.js, deletedMessageGuids,
    m.date > COALESCE(c.last_read_message_timestamp, 0), hasAnyLocation, OR m.date_read > 0,
    AddExternalIdToContacts1750299580000, name of processes, read-status "high" priority shape;
    absent: delete/recoverable, recoverable-delete-chat
  new: serviceName (RCS), reactionEmoji (emoji tapbacks),
    /System/Library/PrivateFrameworks/ChatKit.framework/ChatKit (ChatKit preload; "com.apple.ChatKit" is NOT
    in the source), isGreaterThanOrEqualTo("14.4") (isMinSonoma14_4, name minified), LocalStorage.db,
    findmylocateagent, chacha20poly1305, require("@noble/ciphers/chacha"), secureLocations

Smoke (Air, Rosetta, no app launch; run on an ad-hoc-signed throwaway clone because the staged bundle's
broken official signature gets the binary SIGKILLed — staged bundle itself left unsigned)
  Electron 25.9.8 / Node 18.15.0 x64: require(app.asar/node_modules/@noble/ciphers/chacha.js) OK,
  chacha20poly1305 encrypt/decrypt roundtrip OK, native crypto has no chacha cipher (confirms noble needed),
  bare "@noble/ciphers/chacha" resolves from dist/main.js to the asar copy, better-sqlite3 opens (SQLite 3.43.1).

NOT verified: full app launch, TypeORM migrations against a real config.db, Private API injection of the
rebuilt helper on Sequoia, encrypted Find My on 15.8.1, signing.
EOF
} > "$M"
echo "manifest: $M"
