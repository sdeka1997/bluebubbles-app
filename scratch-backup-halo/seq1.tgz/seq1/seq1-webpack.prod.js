// Out-of-tree build wrapper for sequoia1 (does NOT modify /tmp/wseq-server).
// Identical to packages/server/scripts/webpack.main.prod.config.js except that
// ForkTsChecker type-checks src/ only: the merged tsconfig.json (emoji-tapbacks 0b6da0ad)
// adds test/ to "include", and those test files fail type-checking. Emit is via
// babel-loader and is unaffected by the type checker.
const path = require("path");
const S = "/tmp/wseq-server/packages/server";
const FTC = require("/tmp/wseq-server/node_modules/fork-ts-checker-webpack-plugin");
const cfg = require(path.join(S, "scripts/webpack.main.prod.config.js"));
let swapped = 0;
cfg.plugins = cfg.plugins.map(p => {
    if (p instanceof FTC) {
        swapped++;
        return new FTC({ typescript: { configFile: "/tmp/seq1-tsconfig.src.json" } });
    }
    return p;
});
if (swapped !== 1) throw new Error(`expected 1 ForkTsChecker plugin, found ${swapped}`);
module.exports = cfg;
