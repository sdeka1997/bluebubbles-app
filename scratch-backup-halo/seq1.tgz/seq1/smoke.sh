#!/bin/bash
# Smoke checks on the staged sequoia1 bundle (no app launch).
set -uo pipefail
S="$HOME/BlueBubbles-Staging"
DST="$S/BlueBubbles-Custom-sequoia1.app"
A="$DST/Contents/Resources/app.asar"
export PATH=/nix/var/nix/profiles/default/bin:$PATH
export NODE_PATH="$HOME/BlueBubbles-Server-Build-v812/node_modules"
echo "== header hash vs Info.plist"
nix shell nixpkgs#nodejs_22 -c node -e '
const asar=require("@electron/asar"),c=require("crypto");const a=process.argv[1];
const h=c.createHash("sha256").update(asar.getRawHeader(a).headerString).digest("hex");
const l=asar.listPackage(a);console.log("header",h,"entries",l.length);
for (const p of ["/dist/main.js","/node_modules/@noble/ciphers/chacha.js","/node_modules/@noble/ciphers/package.json","/node_modules/better-sqlite3/build/Release/better_sqlite3.node"]) console.log(l.includes(p)?"ok ":"MISSING ",p);
' "$A"
/usr/libexec/PlistBuddy -c 'Print :ElectronAsarIntegrity:Resources/app.asar:hash' "$DST/Contents/Info.plist"
echo "== arch"; lipo -archs "$DST/Contents/MacOS/BlueBubbles"
echo "== ELECTRON_RUN_AS_NODE require (Rosetta, x86_64 Electron 25)"
ELECTRON_RUN_AS_NODE=1 arch -x86_64 "$DST/Contents/MacOS/BlueBubbles" -e '
const p=process.argv[1]+"/node_modules/@noble/ciphers/chacha.js";
const { chacha20poly1305 } = require(p);
const key=new Uint8Array(32).fill(7), nonce=new Uint8Array(12).fill(9), msg=new TextEncoder().encode("sequoia1");
const ct=chacha20poly1305(key,nonce).encrypt(msg);
const pt=new TextDecoder().decode(chacha20poly1305(key,nonce).decrypt(ct));
const nodeChacha=require("crypto").getCiphers().filter(c=>/chacha/.test(c));
console.log("electron", process.versions.electron, "node", process.versions.node, "arch", process.arch);
console.log("noble chacha20poly1305 roundtrip:", pt, "ct_len", ct.length, "native chacha ciphers:", JSON.stringify(nodeChacha));
// The bare specifier main.js uses, resolved from inside the asar (as dist/main.js would).
const m=require("module").createRequire(process.argv[1]+"/dist/main.js");
console.log("bare @noble/ciphers/chacha resolves to:", m.resolve("@noble/ciphers/chacha"));
console.log("typeof via bare:", typeof m("@noble/ciphers/chacha").chacha20poly1305);
' "$A" 2>&1
echo "EXIT=$?"
echo "== signature state (expected: invalid, not re-signed)"
/usr/bin/codesign --verify --deep --strict -v "$DST" 2>&1 | tail -4
echo "== xattrs"; /usr/bin/xattr "$DST"
