#!/bin/bash
set -u
cd /tmp/wseq-server/packages/server/appResources
for f in private-api/macos10/BlueBubblesHelper.dylib private-api/macos11/BlueBubblesFaceTimeHelper.dylib private-api/macos11/BlueBubblesHelper.dylib; do
  echo "== $f"; git log --format='%h %ad %s' --date=short -3 -- $f; lipo -info $f | sed 's/.*: //'
  printf 'md5 actual %s  file %s\n' "$(md5 -q $f)" "$(tr -d '\n' < $f.md5)"
done
echo "== md5 of official-bundle files (reported by their .md5)"; 
echo "== tray icons history"; git log --format='%h %ad %s' --date=short -2 -- macos/icons
echo "== does v8.12.19 production main.js use icons/tray?"
export PATH=/nix/var/nix/profiles/default/bin:$PATH
NODE_PATH=$HOME/BlueBubbles-Server-Build-v812/node_modules nix shell nixpkgs#nodejs_22 -c node -e '
const a=require("@electron/asar");const m=a.extractFile(process.env.HOME+"/BlueBubbles-v812-Package/app.custom.v8.12.19.asar","dist/main.js").toString();
for (const s of ["icon-darkTemplate","tray-icon-dark","BlueBubblesFaceTimeHelper","macos10"]) console.log(s, m.split(s).length-1);'
grep -o 'tray-icon-dark\|BlueBubblesFaceTimeHelper\|macos10' ../dist/main.js | sort | uniq -c
grep -rn "FaceTimeHelper\|md5" ../src/server/api/privateApi | head -8
