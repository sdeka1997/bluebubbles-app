#!/bin/bash
# Static re-verification + cleanup for sequoia1. Never launches the app binary.
set -uo pipefail
S="$HOME/BlueBubbles-Staging"
DST="$S/BlueBubbles-Custom-sequoia1.app"
P="$HOME/BlueBubbles-v812-Package"
M="$S/SEQUOIA1-MANIFEST.txt"
sha() { /usr/bin/shasum -a 256 "$1" | /usr/bin/cut -d' ' -f1; }
export PATH=/nix/var/nix/profiles/default/bin:$PATH
export NODE_PATH="$HOME/BlueBubbles-Server-Build-v812/node_modules"
echo "== static"
sha "$P/app.custom.sequoia1.asar"; sha "$DST/Contents/Resources/app.asar"
diff -r "$P/app.custom.sequoia1.asar.unpacked" "$DST/Contents/Resources/app.asar.unpacked" && echo unpacked-identical
nix shell nixpkgs#nodejs_22 -c node -e '
const asar=require("@electron/asar"),c=require("crypto"),fs=require("fs");const a=process.argv[1],src=process.argv[2];
console.log("header", c.createHash("sha256").update(asar.getRawHeader(a).headerString).digest("hex"));
for (const f of ["main.js","main.js.map"]) console.log(f, c.createHash("sha256").update(asar.extractFile(a,"dist/"+f)).digest("hex"),
  Buffer.compare(asar.extractFile(a,"dist/"+f), fs.readFileSync(src+"/"+f))===0?"== dist":"DIFFERS from dist");
console.log("noble version", JSON.parse(asar.extractFile(a,"node_modules/@noble/ciphers/package.json")).version);
' "$DST/Contents/Resources/app.asar" /tmp/wseq-server/packages/server/dist
/usr/libexec/PlistBuddy -c 'Print :ElectronAsarIntegrity:Resources/app.asar:hash' "$DST/Contents/Info.plist"
sha "$DST/Contents/Resources/appResources/private-api/macos11/BlueBubblesHelper.dylib"
sha "$DST/Contents/Resources/appResources/macos/tools/findmy-geocoder.js"
ls "$DST/Contents/Resources/appResources/macos/icons/tray"
[ ! -e "$DST/Contents/Resources/appResources/macos/daemons/cloudflare/cloudflare.pid" ] && echo no-cloudflare-pid
echo "Note: each launch of the staged x86_64 binary on the Air (smoke step) raised GUI pop-ups (code-signature crash dialog, Rosetta Intel-support notice); the noble check passed once and the binary was not launched again." >> "$M"
echo "manifest sha256 $(sha "$M")"
echo "== cleanup"
cd /tmp/wseq-server
rm -rf node_modules packages/server/node_modules packages/ui/node_modules
rm -f packages/server/dist/main.js packages/server/dist/main.js.map packages/server/dist/main.js.LICENSE.txt
git status --short --ignored; echo "git-status-done"
git rev-parse --short HEAD
rm -f /tmp/seq1-*.sh /tmp/seq1-build.log /tmp/seq1-build2.log /tmp/seq1-webpack.prod.js /tmp/seq1-tsconfig.src.json
rm -rf /tmp/seq1-smoke
ls -d /tmp/noble-scratch/node_modules/@noble/ciphers
ls -la "$S" "$P" | grep -i sequoia
git -C "$HOME/BlueBubbles-Server-Build-v812" status --short | head -5; echo build-repo-status-done
df -h ~ | tail -1
