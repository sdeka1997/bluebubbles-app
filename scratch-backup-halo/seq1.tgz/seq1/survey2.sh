#!/bin/bash
set -u
cd /tmp/wseq-server
echo "== dist"; ls -la packages/server/dist
echo "== root devEngines"; /usr/bin/python3 -c 'import json;d=json.load(open("package.json"));print("devEngines" in d, d.get("workspaces"))'
echo "== scripts"; /usr/bin/python3 -c 'import json;d=json.load(open("packages/server/package.json"));print(json.dumps(d["scripts"],indent=1));print(json.dumps(d.get("dependencies"),indent=1))'
ls packages/server/scripts
echo "== helper"
H=packages/server/appResources/private-api/macos11/BlueBubblesHelper.dylib
lipo -info $H; md5 -q $H; od -c $H.md5 | tail -2; cat $H.source.txt
git show forkpush/deployed/server-v8.12.19:$H > /tmp/seq1-oldhelper.dylib; lipo -info /tmp/seq1-oldhelper.dylib; shasum -a 256 /tmp/seq1-oldhelper.dylib; rm -f /tmp/seq1-oldhelper.dylib
echo "== appResources tree"; find packages/server/appResources -type f | sort
echo "== git log appResources"; git log --oneline -8 -- packages/server/appResources
echo "== webpack"; ls packages/server/*.js packages/server/scripts/* 2>/dev/null; grep -rn -i 'externals' --include=*.js --include=*.ts --include=*.json packages/server -l 2>/dev/null | grep -v node_modules | head
echo "== ciphers import in src"; grep -rn 'noble' packages/server/src | head
echo "== merge parents"; git log --oneline --first-parent -5; git log -1 --format='%P' HEAD
for r in forkpush/deployed/server-v8.12.19 feat/rcs-service feat/emoji-tapbacks feat/sequoia-findmy forkpush/feat/rcs-service forkpush/feat/emoji-tapbacks forkpush/feat/sequoia-findmy; do printf '%s ' $r; git rev-parse --short=8 $r 2>/dev/null || echo none; done
git merge-base --is-ancestor 9ea8dfd6 HEAD && echo rcs-in; git merge-base --is-ancestor 0180e0f3 HEAD && echo emoji-in; git merge-base --is-ancestor 8765f4e8 HEAD && echo findmy-in; git merge-base --is-ancestor forkpush/deployed/server-v8.12.19 HEAD && echo prod-in
echo "== nix node"; export PATH=/nix/var/nix/profiles/default/bin:$PATH; nix shell nixpkgs#nodejs_22 -c bash -c 'node -v; npm -v; which node'
