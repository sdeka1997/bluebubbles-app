#!/bin/bash
# Stage BlueBubbles-Custom-sequoia1.app on the Air from the official v1.9.9 bundle copied
# read-only from bbsequoia. Does NOT sign.
set -euo pipefail
S="$HOME/BlueBubbles-Staging"
P="$HOME/BlueBubbles-v812-Package"
CPIO="$S/official-1.9.9-sequoia.cpio"
X="$S/.official-extract"
DST="$S/BlueBubbles-Custom-sequoia1.app"
ASAR="$P/app.custom.sequoia1.asar"
SRC_RES="/tmp/wseq-server/packages/server/appResources"
EXPECTED_OFFICIAL_ASAR="889198e228a045d1bbc2ea9377dd6d5022373db34b3b012e674a9cf72ed6c438"
EXPECTED_OFFICIAL_INTEGRITY="0672e2503d226eee7f2ed9a1abeb6832600bb5322408d13081179c007b4a4beb"
EXPECTED_NEW_ASAR="03b95449dfb46baa83242915bc084abee02e6aea05e36f23b9997a5221b69927"
NEW_INTEGRITY="45d69a15aef213c55bbdf3c4bb0005f9c8414bfa4d071088d2fdfdf147ea76ef"
EXPECTED_HELPER="1d8db25dbbe96967b85709e8fff072b5ce9dea04b733785cfc8a93bcc8de2693"
R="Contents/Resources/appResources"
sha256() { /usr/bin/shasum -a 256 "$1" | /usr/bin/cut -d' ' -f1; }
plint() { /usr/libexec/PlistBuddy -c 'Print :ElectronAsarIntegrity:Resources/app.asar:hash' "$1/Contents/Info.plist"; }

[ "$(sha256 "$ASAR")" = "$EXPECTED_NEW_ASAR" ]
[ "$(/usr/bin/find "$ASAR.unpacked" -type f | /usr/bin/wc -l | /usr/bin/tr -d ' ')" = 28 ]
[ "$(sha256 "$SRC_RES/private-api/macos11/BlueBubblesHelper.dylib")" = "$EXPECTED_HELPER" ]

rm -rf "$X" "$DST"
mkdir -p "$X"
/usr/bin/ditto -x "$CPIO" "$X"
OFF="$X/BlueBubbles.app"
echo "== official copy"
[ "$(sha256 "$OFF/Contents/Resources/app.asar")" = "$EXPECTED_OFFICIAL_ASAR" ]
[ "$(plint "$OFF")" = "$EXPECTED_OFFICIAL_INTEGRITY" ]
/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$OFF/Contents/Info.plist"
/usr/bin/codesign -dv "$OFF" 2>&1 | grep -E 'Identifier|TeamIdentifier|Authority=Developer'
# Strict deep verify is expected to fail ONLY on cloudflare.pid (written at runtime into the bundle).
/usr/bin/codesign --verify --deep --strict -v "$OFF" 2>&1 | tail -5 || true
echo "official xattrs on bundle root:"; /usr/bin/xattr "$OFF" || true

echo "official helper signature:"; /usr/bin/codesign -dv "$OFF/$R/private-api/macos11/BlueBubblesHelper.dylib" 2>&1 | grep -E 'Identifier|Authority=Developer|not signed' || true
/bin/mv "$OFF" "$DST"
rmdir "$X"

echo "== asar"
/bin/cp "$ASAR" "$DST/Contents/Resources/app.asar"
/bin/chmod 644 "$DST/Contents/Resources/app.asar"
rm -rf "$DST/Contents/Resources/app.asar.unpacked"
/usr/bin/ditto "$ASAR.unpacked" "$DST/Contents/Resources/app.asar.unpacked"
/usr/libexec/PlistBuddy -c "Set :ElectronAsarIntegrity:Resources/app.asar:hash $NEW_INTEGRITY" "$DST/Contents/Info.plist"

echo "== appResources"
# Rebuilt Private API helper (+ md5 + provenance note) from feat/emoji-tapbacks 0180e0f3.
for f in BlueBubblesHelper.dylib BlueBubblesHelper.dylib.md5 BlueBubblesHelper.dylib.source.txt; do
  /bin/cp "$SRC_RES/private-api/macos11/$f" "$DST/$R/private-api/macos11/$f"
done
/bin/chmod 755 "$DST/$R/private-api/macos11/BlueBubblesHelper.dylib"
/bin/chmod 644 "$DST/$R/private-api/macos11/BlueBubblesHelper.dylib.md5" "$DST/$R/private-api/macos11/BlueBubblesHelper.dylib.source.txt"
# Find My geocoder script (#855): main.js spawns appResources/macos/tools/findmy-geocoder.js.
/bin/cp "$SRC_RES/macos/tools/findmy-geocoder.js" "$DST/$R/macos/tools/findmy-geocoder.js"
/bin/chmod 644 "$DST/$R/macos/tools/findmy-geocoder.js"
# Tray icons: main.js (AppTray) loads appResources/macos/icons/tray/icon-{dark,light}Template.png;
# the official 1.9.9 bundle only has macos/icons/tray-icon-{dark,light}.png.
mkdir -p "$DST/$R/macos/icons/tray"
for f in icon-darkTemplate.png icon-darkTemplate@2x.png icon-lightTemplate.png icon-lightTemplate@2x.png; do
  /bin/cp "$SRC_RES/macos/icons/tray/$f" "$DST/$R/macos/icons/tray/$f"
  /bin/chmod 644 "$DST/$R/macos/icons/tray/$f"
done
# Runtime file written by the running app; never ship it.
rm -f "$DST/$R/macos/daemons/cloudflare/cloudflare.pid"

echo "== verify"
[ "$(sha256 "$DST/Contents/Resources/app.asar")" = "$EXPECTED_NEW_ASAR" ]
[ "$(plint "$DST")" = "$NEW_INTEGRITY" ]
[ "$(/usr/bin/find "$DST/Contents/Resources/app.asar.unpacked" -type f | /usr/bin/wc -l | /usr/bin/tr -d ' ')" = 28 ]
diff -r "$ASAR.unpacked" "$DST/Contents/Resources/app.asar.unpacked"
[ "$(sha256 "$DST/$R/private-api/macos11/BlueBubblesHelper.dylib")" = "$EXPECTED_HELPER" ]
[ "$(/sbin/md5 -q "$DST/$R/private-api/macos11/BlueBubblesHelper.dylib")" = "$(tr -d '\n' < "$DST/$R/private-api/macos11/BlueBubblesHelper.dylib.md5")" ]
[ ! -e "$DST/$R/macos/daemons/cloudflare/cloudflare.pid" ]
rm -f "$CPIO"
echo "staged: $DST"
