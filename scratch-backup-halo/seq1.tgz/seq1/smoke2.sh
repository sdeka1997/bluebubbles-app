#!/bin/bash
# Run the @noble/ciphers require check on an ad-hoc-signed THROWAWAY clone of the staged app.
# The staged deliverable itself is left unsigned.
set -uo pipefail
DST="$HOME/BlueBubbles-Staging/BlueBubbles-Custom-sequoia1.app"
T=/tmp/seq1-smoke
rm -rf "$T"; mkdir -p "$T"
/bin/cp -cR "$DST" "$T/BB.app"
/usr/bin/codesign --force --deep --sign - "$T/BB.app" 2>&1 | tail -2
/usr/bin/codesign --verify --deep --strict "$T/BB.app" && echo "clone adhoc-signed ok"
A="$T/BB.app/Contents/Resources/app.asar"
ELECTRON_RUN_AS_NODE=1 arch -x86_64 "$T/BB.app/Contents/MacOS/BlueBubbles" -e '
const a=process.argv[process.argv.length-1];
const { chacha20poly1305 } = require(a+"/node_modules/@noble/ciphers/chacha.js");
const key=new Uint8Array(32).fill(7), nonce=new Uint8Array(12).fill(9), msg=new TextEncoder().encode("sequoia1");
const ct=chacha20poly1305(key,nonce).encrypt(msg);
const pt=new TextDecoder().decode(chacha20poly1305(key,nonce).decrypt(ct));
console.log("electron", process.versions.electron, "node", process.versions.node, "arch", process.arch);
console.log("noble chacha20poly1305 roundtrip:", pt, "ct_len", ct.length, "native chacha ciphers:", JSON.stringify(require("crypto").getCiphers().filter(c=>/chacha/.test(c))));
const m=require("module").createRequire(a+"/dist/main.js");
console.log("bare @noble/ciphers/chacha ->", m.resolve("@noble/ciphers/chacha"), typeof m("@noble/ciphers/chacha").chacha20poly1305);
const D=m("better-sqlite3"); const db=new D(":memory:"); console.log("better-sqlite3 in-asar:", db.prepare("select sqlite_version() v").get().v); db.close();
' "$A" 2>&1
echo "EXIT=$?"
rm -rf "$T"
/usr/bin/codesign -dv "$DST" 2>&1 | grep -E 'TeamIdentifier|Signature=adhoc' || true
