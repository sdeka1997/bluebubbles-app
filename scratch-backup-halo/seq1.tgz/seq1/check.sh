#!/bin/bash
set -u
cd /tmp/wseq-server
M=packages/server/dist/main.js
shasum -a 256 $M $M.map $M.LICENSE.txt
echo "== externals noble"; grep -o 'require("@noble[^"]*")' $M | sort | uniq -c
echo "== all externals"; grep -o 'require("[^"./][^"]*")' $M | sort -u | tr '\n' ' '; echo
echo "== markers"
for m in swapnav/readsync-findmy-v812 CUSTOM_BUILD_UPDATE_DISABLED BeaconStoreKey chat-deleted chat-state/snapshot 'filename*=UTF-8' isFilteredAsSpam message-deleted message-restored chat_recoverable_message_join SMSCategory 'newer_m.date > m.date' favorite_order 'Skipping FCM notification: the message is too large' findmy-geocoder.js deletedMessageGuids 'm.date > COALESCE(c.last_read_message_timestamp, 0)' hasAnyLocation 'OR m.date_read > 0' AddExternalIdToContacts1750299580000 'name of processes' delete/recoverable recoverable-delete-chat serviceName reactionEmoji isMinSonoma14_4 LocalStorage.db findmylocateagent chacha20poly1305 com.apple.ChatKit ChatKit.framework/ChatKit FMIP Sequoia; do printf '%-55s %s\n' "$m" "$(grep -oF -- "$m" $M | wc -l | tr -d ' ')"; done
grep -cE 'function \w+\(t,e\)\{return t===\w+\?"high":e\}' $M
echo "== base dist listing"
ls node_modules/@electron/asar/package.json && grep '"version"' node_modules/@electron/asar/package.json ~/BlueBubbles-Server-Build-v812/node_modules/@electron/asar/package.json
echo "== noble"
grep '"version"' node_modules/@noble/ciphers/package.json /tmp/noble-scratch/node_modules/@noble/ciphers/package.json
diff -rq node_modules/@noble/ciphers /tmp/noble-scratch/node_modules/@noble/ciphers && echo noble-identical
/usr/bin/python3 -c 'import json;d=json.load(open("/tmp/noble-scratch/node_modules/@noble/ciphers/package.json"));print(d.get("type"),d.get("main"),d.get("dependencies"),json.dumps(d["exports"].get("./chacha")), json.dumps(d["exports"].get("./chacha.js")))'
ls /tmp/noble-scratch; ls /tmp/noble-scratch/node_modules; du -sh /tmp/noble-scratch/node_modules/@noble/ciphers
git status --short --ignored
