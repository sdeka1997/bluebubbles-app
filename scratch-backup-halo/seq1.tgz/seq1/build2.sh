#!/bin/bash
# Build main.js for sequoia1 via the out-of-tree wrapper (src-only type check).
set -uo pipefail
export PATH=/nix/var/nix/profiles/default/bin:$PATH
LOG=/tmp/seq1-build2.log
cd /tmp/wseq-server/packages/server
{
echo "start $(date)"
nix shell nixpkgs#nodejs_22 -c bash -c '
  set -e
  node -v; npm -v
  export NODE_ENV=production
  ../../node_modules/.bin/webpack --config /tmp/seq1-webpack.prod.js
'
echo "EXIT=$?"
} > "$LOG" 2>&1
