#!/bin/bash
# Build main.js for sequoia1 from /tmp/wseq-server with the build-server.sh toolchain.
set -uo pipefail
export PATH=/nix/var/nix/profiles/default/bin:$PATH
LOG=/tmp/seq1-build.log
cd /tmp/wseq-server
{
echo "start $(date)"
nix shell nixpkgs#nodejs_22 -c bash -c '
  set -e
  node -v; npm -v
  if [ ! -d node_modules ]; then echo "npm ci"; npm ci --ignore-scripts --no-audit --no-fund; fi
  npm ls @noble/ciphers @electron/asar better-sqlite3 2>&1 | head -20 || true
  npm run build --workspace packages/server
'
echo "EXIT=$?"
} > "$LOG" 2>&1
