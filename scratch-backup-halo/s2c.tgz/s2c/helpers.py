import subprocess, shlex
REPO='~/BlueBubbles-Alpha-Build/experiments/seq1'
TREE='/home/swapnav/.hermes/work/s2c/tree'
def sh(cmd, timeout=280):
    r=subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
    return (r.stdout+r.stderr)
def push(*paths):
    ps=' '.join(shlex.quote(p) for p in paths)
    return sh(f"cd {TREE} && tar czf - {ps} | ssh mac 'cd {REPO} && tar xzf -'")
def pull(*paths):
    ps=' '.join(paths)
    return sh(f"ssh mac 'cd {REPO} && tar czf - {ps}' | tar xzf - -C {TREE}")
def mac(cmd, timeout=280):
    open('/tmp/rs.sh','w').write(cmd)
    sh("scp -q /tmp/rs.sh mac:/tmp/rs.sh")
    return sh("ssh mac 'perl -e \"alarm shift; exec @ARGV\" %d bash /tmp/rs.sh'" % (timeout-10), timeout=timeout)
CLEAN = "git restore macos/Flutter/Flutter-Debug.xcconfig macos/Flutter/Flutter-Release.xcconfig ios/Flutter/ephemeral/flutter_lldb_helper.py ios/Flutter/ephemeral/flutter_lldbinit 2>/dev/null; rm -f ios/Flutter/ephemeral/.swift_pm.lock macos/Podfile; rm -rf ios/Flutter/ephemeral/Packages; rm -f .env"
def test(f, filt=None, timeout=280):
    out = mac(f"bash /tmp/app-test.sh {REPO} {f}", timeout)
    return out
def testfull(f, timeout=280):
    # full output with assertion detail
    return mac(f"cd {REPO} && export PATH=$HOME/BlueBubbles-Alpha-Build/toolchain/flutter/bin:$PATH && touch .env && flutter test {f} 2>&1 | grep -vE '^\\s*$' | grep -E 'Expected|Actual|Which|Error|error|All tests|Some tests|\\+[0-9]+.*-[0-9]+|FK proof|BENCH|BBSQL|: [a-z_]+: \\[|Exception|reason|line|Failed' | head -120; {CLEAN}", timeout)
