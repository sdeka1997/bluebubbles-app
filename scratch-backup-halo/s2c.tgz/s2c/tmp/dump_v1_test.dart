import 'dart:io';
import 'package:bluebubbles/database/sqlite/app_database.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('dump v1 ddl', () async {
    final db = AppDatabase.inMemory();
    final rows = await db.customSelect("SELECT type, name, sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY CASE type WHEN 'table' THEN 0 ELSE 1 END, rowid").get();
    final out = StringBuffer();
    for (final r in rows) { out.writeln('${r.read<String>('sql')};'); }
    File('/tmp/schema_v1.sql').writeAsStringSync(out.toString());
    await db.close();
  });
}
