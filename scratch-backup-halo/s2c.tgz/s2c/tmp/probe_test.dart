import 'dart:io';
import 'package:bluebubbles/database/models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('probe objectbox contains', () async {
    final dir = Directory.systemTemp.createTempSync('probe_');
    final store = Store(getObjectBoxModel(), directory: dir.path);
    final texts = ['Café OK', 'CAFÉ', 'ÉCOLE', 'école', 'Straße', 'STRASSE', 'İstanbul', 'ΣΊΣΥΦΟΣ', 'σίσυφος', 'abc', 'ABC', 'a_b', 'a%b', 'naïve'];
    store.box<Message>().putMany([for (final t in texts) Message(guid: t, text: t, dateCreated: DateTime(2020))]);
    for (final term in ['é', 'É', 'café', 'CAFÉ', 'école', 'ÉCOLE', 'ss', 'ß', 'straße', 'σίσ', 'ΣΊΣ', 'istanbul', 'İst', 'ab', '_', '%', 'a_b']) {
      final q = store.box<Message>().query(Message_.text.contains(term, caseSensitive: false)).build();
      print('TERM $term -> ${q.find().map((m) => m.text).toList()}');
      q.close();
    }
    store.close();
    dir.deleteSync(recursive: true);
  });
}
